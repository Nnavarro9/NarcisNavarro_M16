const regsitrarButton = document.getElementById("logejat");
//const correoField = document.getElementById("correo");
//const passwordField = document.getElementById("contrasenya");
// Agregar un controlador de events al botó
registrarButton.addEventListener("click", function() {
    // Redirigir a la página "registre.html"
    window.location.href = "mainprova.html?";
});