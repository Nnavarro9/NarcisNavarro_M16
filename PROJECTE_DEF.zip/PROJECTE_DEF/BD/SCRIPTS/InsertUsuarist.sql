USE ProjecteM16;

DELETE FROM usuari;
